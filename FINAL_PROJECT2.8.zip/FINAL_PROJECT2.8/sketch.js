let bring;
let lord;
let song1;
let song2;
let button;
// var on = false;


function preload(){
  bring = loadSound("bring.mp3");
  lord = loadSound("lord.mp3");
}

function setup() {
  createCanvas(900, 650);
  song1 = loadSound("bring.mp3", loaded);
  button = createButton("play");
  button.mousePressed(togglePlaying);
}

function loaded(){
  console.log("loaded");
}

function togglePlaying(){

  if (!song.isPlaying()){
    song.play();
    song.setVolume(0.3);
    button.html("pause");
  } else {
    song.pause();
    button.html("play");
  }
}

function mousePressed(){
  if (mouseX > 50 && mouseX <150 && mouseY > 50 && mouseY <150)
  {
  on = true;

  }
}

function draw() {
  background(220);
}
